# Windows Setup Instructions

## Quick Start

1. **Download the project:**
   - Click the green "Code" button on GitHub
   - Download as ZIP and extract to your desired location

2. **Run the setup:**
   - Double-click `setup.bat` to automatically install dependencies
   - Or manually run: `pip install pyperclip zxcvbn`

3. **Launch the application:**
   - **GUI Version:** Double-click `password_generator_gui.py` or run `python password_generator_gui.py`
   - **Command Line:** Run `python password_generator.py`

## Manual Installation

If the setup script doesn't work:

1. **Install Python:**
   - Download from [python.org](https://python.org)
   - Make sure to check "Add Python to PATH" during installation

2. **Install dependencies:**
   ```cmd
   pip install pyperclip zxcvbn
   ```

3. **Run the application:**
   ```cmd
   python password_generator_gui.py
   ```

## Troubleshooting

**"Python is not recognized":**
- Python is not installed or not in PATH
- Reinstall Python and check "Add Python to PATH"

**"Module not found" errors:**
- Run `pip install pyperclip zxcvbn` to install missing dependencies

**Virtual environment issues:**
- The project includes a pre-configured virtual environment in the `venv` folder
- Use `venv\Scripts\python.exe` to run the application with the virtual environment