import csv
import random
import string
import tkinter as tk
from datetime import datetime, timedelta
from tkinter import messagebox, filedialog
from tkinter.font import Font

import pyperclip
import zxcvbn

HISTORY_FILE = 'password_history.txt'
EXPIRATION_DAYS = 90

# Modern color scheme
PRIMARY_COLOR = "#2563eb"  # Blue
SECONDARY_COLOR = "#1e40af"  # Darker blue
ACCENT_COLOR = "#10b981"  # Green
DANGER_COLOR = "#ef4444"  # Red
BG_COLOR = "#f8fafc"  # Light gray
CARD_COLOR = "#ffffff"  # White
TEXT_COLOR = "#1e293b"  # Dark blue-gray
MUTED_COLOR = "#64748b"  # Muted blue-gray


def generate_password(length=12, include_letters=True, include_digits=True, include_symbols=True):
    characters = ''
    if include_letters:
        characters += string.ascii_letters
    if include_digits:
        characters += string.digits
    if include_symbols:
        characters += string.punctuation

    password = ''.join(random.choice(characters) for _ in range(length))
    return password


def evaluate_password_strength(password):
    result = zxcvbn.zxcvbn(password)
    # Suppress yellow underline: The 'score' key is present in the result dictionary
    score = result['score']  # type: ignore
    feedback = result['feedback']['suggestions'][0] if result['feedback'][
        'suggestions'] else 'Strong and secure password!'
    return score, feedback


def copy_to_clipboard(text):
    pyperclip.copy(text)


def save_password_to_history(password):
    expiration_date = datetime.now() + timedelta(days=EXPIRATION_DAYS)
    with open(HISTORY_FILE, 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([password, expiration_date.strftime('%Y-%m-%d')])


# Function to handle the Save button click event
def save_password_handler():
    password = password_label['text'][19:]  # Extract the generated password from the label text

    filename = filedialog.asksaveasfilename(
        defaultextension=".csv",
        filetypes=[("CSV Files", "*.csv"), ("Text Files", "*.txt"), ("All Files", "*.*")],
        title="Save Password"
    )

    if filename:
        save_password_to_history(password)
        with open(filename, 'a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([password, datetime.now().strftime('%Y-%m-%d')])
        messagebox.showinfo("Password Saved", f"Password saved to file:\n{filename}")
    else:
        messagebox.showwarning("No File Selected",
                               "No file selected. Password saved in default location (password_history.txt).")


# Function to fade the "Copied to clipboard" label
def fade_copied_label():
    copied_label.config(text="")
    copied_label.after(3000, lambda: copied_label.config(fg="white"))


# Create the main window with modern styling
window = tk.Tk()
window.title("🔐 Secure Password Generator")
window.configure(bg=BG_COLOR)

# Get screen width and height
screen_width = window.winfo_screenwidth()
screen_height = window.winfo_screenheight()

# Calculate the center position
window_width = 700
window_height = 800  # Made taller vertically
x = (screen_width - window_width) // 2
y = (screen_height - window_height) // 2

# Set the window geometry
window.geometry(f"{window_width}x{window_height}+{x}+{y}")
window.resizable(False, False)

# Create a custom font for headings
title_font = Font(family="Segoe UI", size=24, weight="bold")
label_font = Font(family="Segoe UI", size=12, weight="normal")
button_font = Font(family="Segoe UI", size=14, weight="bold")


# Function to generate a password and display it
def generate_password_handler():
    try:
        length = int(length_entry.get())
        if length < 4:
            messagebox.showwarning("Invalid Length", "Password length must be at least 4 characters.")
            return
        if length > 128:
            messagebox.showwarning("Invalid Length", "Password length cannot exceed 128 characters.")
            return
            
        include_letters = letters_var.get()
        include_digits = digits_var.get()
        include_symbols = symbols_var.get()

        # Check if at least one character type is selected
        if not (include_letters or include_digits or include_symbols):
            messagebox.showwarning("Selection Required", "Please select at least one character type.")
            return

        password = generate_password(
            length=length,
            include_letters=include_letters,
            include_digits=include_digits,
            include_symbols=include_symbols
        )

        password_label.config(text=password)
        save_button.config(state="normal", bg=ACCENT_COLOR, fg="white")

        # Evaluate password strength
        score, feedback = evaluate_password_strength(password)
        max_score = 4  # zxcvbn scores from 0-4

        # Update strength display with visual indicator
        strength_text = f"Strength: {score}/{max_score}"
        strength_label.config(text=strength_text)
        
        # Color code the strength indicator
        if score == 0:
            strength_label.config(fg=DANGER_COLOR)
            strength_bar.config(bg=DANGER_COLOR, width=10)
        elif score == 1:
            strength_label.config(fg="#f59e0b")  # Orange
            strength_bar.config(bg="#f59e0b", width=20)
        elif score == 2:
            strength_label.config(fg="#eab308")  # Yellow
            strength_bar.config(bg="#eab308", width=30)
        elif score == 3:
            strength_label.config(fg="#22c55e")  # Light green
            strength_bar.config(bg="#22c55e", width=40)
        else:
            strength_label.config(fg=ACCENT_COLOR)
            strength_bar.config(bg=ACCENT_COLOR, width=50)

        feedback_label.config(text=feedback if feedback != 'Strong and secure password!' else "Excellent choice! 🎉")

        # Copy the password to clipboard
        copy_to_clipboard(password)
        copied_label.config(text="Copied to Clipboard", fg=ACCENT_COLOR)
        copied_label.after(2000, lambda: copied_label.config(text=""))
        
        # Show popup window for successful generation
        show_success_popup()
        
    except ValueError:
        messagebox.showerror("Invalid Input", "Please enter a valid number for password length.")


# Function to show success popup window
def show_success_popup():
    popup = tk.Toplevel(window)
    popup.title("Success!")
    popup.configure(bg=ACCENT_COLOR)
    popup.geometry("400x150")  # Made wider horizontally
    popup.resizable(False, False)
    
    # Center the popup on screen
    popup_width = 400  # Increased width
    popup_height = 150
    screen_width = popup.winfo_screenwidth()
    screen_height = popup.winfo_screenheight()
    popup_x = (screen_width - popup_width) // 2
    popup_y = (screen_height - popup_height) // 2
    popup.geometry(f"{popup_width}x{popup_height}+{popup_x}+{popup_y}")
    
    # Make popup always on top and remove close button
    popup.attributes('-topmost', True)
    popup.overrideredirect(True)  # Remove window decorations (including X button)
    
    # Success message
    success_label = tk.Label(popup, text="✅ Password Generated Successfully!", 
                           font=Font(family="Segoe UI", size=14, weight="bold"), 
                           fg="white", bg=ACCENT_COLOR)
    success_label.pack(expand=True, pady=20)
    
    # Auto-close after 2 seconds
    popup.after(2000, popup.destroy)


# Create main container with padding
main_container = tk.Frame(window, bg=BG_COLOR, padx=40, pady=30)
main_container.pack(fill="both", expand=True)

# Header section
header_frame = tk.Frame(main_container, bg=CARD_COLOR, relief="raised", bd=2)
header_frame.pack(fill="x", pady=(0, 20))

title_label = tk.Label(header_frame, text="🔐 Secure Password Generator", 
                      font=title_font, fg=TEXT_COLOR, bg=CARD_COLOR, pady=15)
title_label.pack()

subtitle_label = tk.Label(header_frame, text="Generate strong, secure passwords in seconds", 
                         font=label_font, fg=MUTED_COLOR, bg=CARD_COLOR)
subtitle_label.pack(pady=(0, 10))

# Settings section
settings_frame = tk.LabelFrame(main_container, text="Password Settings", font=label_font, 
                              bg=CARD_COLOR, padx=20, pady=15, relief="solid", bd=1)
settings_frame.pack(fill="x", pady=(0, 20))

# Password length setting
length_frame = tk.Frame(settings_frame, bg=CARD_COLOR)
length_frame.pack(fill="x", pady=5)

length_label = tk.Label(length_frame, text="Password Length:", font=label_font, fg=TEXT_COLOR, bg=CARD_COLOR, width=15, anchor="w")
length_label.pack(side="left")

length_entry = tk.Entry(length_frame, font=label_font, width=10, relief="solid", bd=1)
length_entry.insert(0, "12")
length_entry.pack(side="right", padx=(0, 10))

# Character type checkboxes
checkbox_frame = tk.Frame(settings_frame, bg=CARD_COLOR)
checkbox_frame.pack(fill="x", pady=10)

letters_var = tk.BooleanVar(value=True)
letters_checkbox = tk.Checkbutton(checkbox_frame, text="🔤 Letters (a-z, A-Z)", variable=letters_var, 
                                 font=label_font, fg=TEXT_COLOR, bg=CARD_COLOR, selectcolor=CARD_COLOR, activebackground=CARD_COLOR)
letters_checkbox.pack(anchor="w", pady=2)

digits_var = tk.BooleanVar(value=True)
digits_checkbox = tk.Checkbutton(checkbox_frame, text="🔢 Digits (0-9)", variable=digits_var, 
                                font=label_font, fg=TEXT_COLOR, bg=CARD_COLOR, selectcolor=CARD_COLOR, activebackground=CARD_COLOR)
digits_checkbox.pack(anchor="w", pady=2)

symbols_var = tk.BooleanVar(value=True)
symbols_checkbox = tk.Checkbutton(checkbox_frame, text="⚡ Symbols (!@#$%)", variable=symbols_var, 
                                 font=label_font, fg=TEXT_COLOR, bg=CARD_COLOR, selectcolor=CARD_COLOR, activebackground=CARD_COLOR)
symbols_checkbox.pack(anchor="w", pady=2)

# Generate button
generate_button = tk.Button(main_container, text="🚀 Generate Password", command=generate_password_handler, 
                           font=button_font, bg=PRIMARY_COLOR, fg="white", relief="flat", height=2, cursor="hand2")
generate_button.pack(fill="x", pady=(0, 20))
generate_button.bind("<Enter>", lambda e: generate_button.config(bg=SECONDARY_COLOR))
generate_button.bind("<Leave>", lambda e: generate_button.config(bg=PRIMARY_COLOR))

# Results section
results_frame = tk.LabelFrame(main_container, text="Generated Password", font=label_font, 
                             bg=CARD_COLOR, padx=20, pady=15, relief="solid", bd=1)
results_frame.pack(fill="both", expand=True, pady=(0, 20))

# Password display
password_frame = tk.Frame(results_frame, bg=CARD_COLOR)
password_frame.pack(fill="x", pady=10)

password_label = tk.Label(password_frame, text="Your password will appear here", 
                         font=("Courier New", 16, "bold"), fg=TEXT_COLOR, bg="#f8fafc", relief="solid", 
                         bd=2, padx=15, pady=12, wraplength=550, justify="center", height=2)
password_label.pack(fill="x", pady=(0, 15))

# Action buttons
button_frame = tk.Frame(results_frame, bg=CARD_COLOR)
button_frame.pack(fill="x", pady=(0, 15))

save_button = tk.Button(button_frame, text="💾 Save Password", command=save_password_handler,
                       font=button_font, bg=ACCENT_COLOR, fg="white", relief="flat", state="disabled", 
                       cursor="hand2", height=2, width=15, pady=5)
save_button.pack(side="right", padx=(10, 0), pady=(0, 10))

# Strength indicator with better layout
strength_frame = tk.LabelFrame(results_frame, text="Security Analysis", font=label_font, 
                              bg=CARD_COLOR, padx=15, pady=10, relief="solid", bd=1)
strength_frame.pack(fill="x", pady=(0, 15))

strength_display = tk.Frame(strength_frame, bg=CARD_COLOR)
strength_display.pack(fill="x", pady=5)

strength_label = tk.Label(strength_display, text="Strength: --/--", font=label_font, fg=MUTED_COLOR, bg=CARD_COLOR, width=15, anchor="w")
strength_label.pack(side="left")

strength_bar = tk.Label(strength_display, text="", bg=MUTED_COLOR, height=2, width=40)
strength_bar.pack(side="left", padx=(10, 0), fill="x", expand=True)

# Feedback section with better spacing
feedback_frame = tk.LabelFrame(main_container, text="Security Feedback", font=label_font, 
                              bg=CARD_COLOR, padx=20, pady=15, relief="solid", bd=1)
feedback_frame.pack(fill="x", pady=(0, 20))

feedback_label = tk.Label(feedback_frame, text="Generate a password to see security feedback", 
                         font=label_font, fg=MUTED_COLOR, bg=CARD_COLOR, wraplength=600, justify="left", height=3)
feedback_label.pack(fill="x")

# Footer with instructions
footer_frame = tk.Frame(main_container, bg=CARD_COLOR, relief="raised", bd=1)
footer_frame.pack(fill="x", pady=(0, 0))

footer_label = tk.Label(footer_frame, text="💡 Tip: Use longer passwords with mixed character types for maximum security", 
                       font=label_font, fg=MUTED_COLOR, bg=CARD_COLOR, pady=10)
footer_label.pack()

# Copy confirmation label - made much more prominent
copied_label = tk.Label(main_container, text="", 
                       font=Font(family="Segoe UI", size=16, weight="bold"), 
                       fg=ACCENT_COLOR, bg=BG_COLOR, pady=15)
copied_label.pack(pady=(0, 10))

# Run the Tkinter event loop
window.mainloop()
