@echo off
echo Launching Secure Password Generator...
echo.

REM Check if virtual environment exists
if not exist "venv\Scripts\python.exe" (
    echo Virtual environment not found. Please run setup.bat first.
    pause
    exit /b 1
)

REM Launch the GUI
echo Starting GUI interface...
start "" "venv\Scripts\python.exe" "password_generator_gui.py"

echo.
echo You can also use the command-line version:
echo   venv\Scripts\python.exe password_generator.py
echo.
echo Press any key to exit...
pause >nul