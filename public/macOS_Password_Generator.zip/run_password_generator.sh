#!/bin/bash

echo "Launching Secure Password Generator..."
echo ""

# Check if virtual environment exists
if [ ! -f "venv/bin/python" ]; then
    echo "Virtual environment not found. Please run setup first."
    echo "Run: pip install -r requirements.txt"
    exit 1
fi

# Launch the GUI
echo "Starting GUI interface..."
python3 venv/bin/python password_generator_gui.py &

echo ""
echo "You can also use the command-line version:"
echo "  python3 venv/bin/python password_generator.py"
echo ""
echo "Press Enter to exit..."
read