# Password Generator

A simple, secure password generator with GUI and command-line interfaces.

## Quick Start

### For Portfolio Visitors (One-Click Download)

**Windows 11:**
1. Download `Windows_Password_Generator.zip`
2. Extract the ZIP file
3. Double-click `run_password_generator.bat`
4. Done!

**macOS:**
1. Download `macOS_Password_Generator.zip`
2. Extract the ZIP file
3. Open Terminal, navigate to folder: `cd [folder-name]`
4. Run: `chmod +x run_password_generator.sh`
5. Double-click `run_password_generator.sh` or run: `./run_password_generator.sh`
6. Done!

### For Developers

**Install:**
```bash
git clone https://github.com/nickynault/Password-Generator.git
cd Password-Generator
pip install -r requirements.txt
```

**Usage:**
```bash
# GUI version
python password_generator_gui.py

# Command-line version
python password_generator.py -l 16 -lt -d -s
```

## Features

- Generate secure passwords with visual strength analysis
- Copy to clipboard automatically with confirmation popup
- Save passwords to history and export to files
- Pre-configured virtual environment - no setup needed for users
- Cross-platform support (Windows 11, macOS)

## License
MIT
