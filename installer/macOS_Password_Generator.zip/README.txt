🔒 Password Generator for macOS

How to Use:
1. Open Terminal
2. Navigate to this folder: cd /path/to/PasswordGenerator
3. Make the script executable: chmod +x PasswordGenerator.sh
4. Run: ./PasswordGenerator.sh
5. If Python is not installed, download from: https://python.org

Features:
- Generate secure passwords with customizable length
- Choose character types (uppercase, lowercase, numbers, symbols)
- Copy passwords to clipboard
- Save passwords to local history
- Professional, user-friendly interface

Requirements:
- Python 3.x (download from https://python.org)
- tkinter (usually included with Python)

Troubleshooting:
- If you get an error, make sure Python is installed
- You may need to run: pip3 install tkinter
- Contact nickarsenault18@gmail.com for support